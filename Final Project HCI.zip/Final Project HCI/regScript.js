function check(){

 var nameval = document.getElementById("nameid").value;
 var emailval = document.getElementById("emailid").value;
 var passval = document.getElementById("passid").value;
 var countryval = document.getElementById("countryid").value;
 var addressval = document.getElementById("addressid").value;
 var prefval = document.getElementById("prefid").value;

 var letters = /^[a-z]*$/i;
 //Validation 1
    if(nameval=="") alert("Fullname Cannot be blank!");
    else if(form.emailid.value=="") alert("Email Cannot be blank!");
    else if(form.passid.value=="") alert("Password Cannot be blank!");
    else if(form.countryid.value=="") alert("Country Cannot be blank!");
    else if(form.addressid.value=="") alert("Address Cannot be blank!");
    else if(form.prefid.value=="") alert("Art Preferences Cannot be blank!");

//Validation 2
    else if(passval.length<8)alert("Password must be greater than 8 characters!");
    
//Validation 3
   else if(!emailval.includes("@gmail.com")) alert("Email must contain '@gmail.com' !");

//Validation 4
    
   else if (!nameval.match(letters)) alert("Name must only use letters!");
    
 //Validation 5
 else if (passval.indexOf(" ") > -1)
 {
   alert("Password cannot contain whitespaces!");
 }


 else{

    alert("Registration Successfull !");

 }

}