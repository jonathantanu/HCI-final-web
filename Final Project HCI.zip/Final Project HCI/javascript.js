$(document).ready(function () {

    var slideCount = $('#slider .slideImages .slideImage').length;
    var slideWidth = $('#slider .slideImages .slideImage').width();
    var slideHeight = $('#slider .slideImages .slideImage').height();
    var totalWidth = slideCount * slideWidth + 1;

    $('#slider').css({width: slideWidth, height: slideHeight});
    $('#slider .slideImages').css({width: totalWidth, marginLeft: - slideWidth});
    $('#slider .slideImages .slideImage:last-child').prependTo('#slider .slideImages');

   
    $(".prevBtn").click(function () {
        $('#slider .slideImages').animate({
            left: + slideWidth
        }, 1000, function () {
            $('#slider .slideImages .slideImage:last-child').prependTo('#slider .slideImages');
            $('#slider .slideImages').css('left', '0');
        });
    });

    $(".nextBtn").click(function () {
        $('#slider .slideImages').animate({
            left: - slideWidth
        }, 1000, function () {
            $('#slider .slideImages .slideImage:first-child').appendTo('#slider .slideImages');
            $('#slider .slideImages').css('left', '0');
        });
    });
});

